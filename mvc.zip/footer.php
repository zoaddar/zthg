</div>

		<footer class="footer">
			<p>&copy; 2016 <a href="http://zoaddar.org">zoaddar.org</a>, Inc.</p>
		</footer>
	</div> <!-- /container -->

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="inc/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
